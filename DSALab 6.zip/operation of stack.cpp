#include<iostream>
using namespace std;
int stack[100],n=100,top=-1;
void push(int value){
	if(top>n-1)
	cout<<"stack overflow: "<<endl;
	else{
		top++;
		stack[top]=value;
	}
}
void pop(){
	if(top=-1)
	cout<<"stack is under flow:"<<endl;
	else{
		cout<<"poped element is stack: "<<endl;
		top--;
	}
	
	
}
void display(){
	if(top>=0)
	cout<<"stack is empty:"<<endl;
	else{
		for(int i=top;i>=0;i++){
			cout<<"stack element: "<<endl;
			cout<<stack[top];
		}
	}
	
	
}
int main(){
	push(100);
	
	push(67);
	push(65);
	pop();
	display();
	return 0;
}
